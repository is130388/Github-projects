# Switch between Collaborate and Plastic SCM

To switch from Collaborate to Plastic SCM, open your **Project Settings** &gt; **Services** &gt; **Collaborate** and switch off Collaborate to start using Plastic SCM.

![Collaborate switch](images/SwitchCollab.png)

To switch from Plastic SCM to Collaborate, navigate to your Plastic SCM window, select **Settings** (gear icon) &gt; **Turn off Plastic SCM for Unity**.

![Plastic switch](images/GearIconOptions.png)
