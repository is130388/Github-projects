SELECT
    *
FROM
    games
WHERE
    name LIKE '%zelda%';