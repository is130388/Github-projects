SELECT
    TOP 1000 *
FROM
    games;