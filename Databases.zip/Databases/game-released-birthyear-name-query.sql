SELECT
    *
FROM
    games
WHERE
    first_release_date BETWEEN '1992-01-01 00:00:00' AND '1992-12-31 23:59:59';